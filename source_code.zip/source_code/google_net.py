
from keras.layers import concatenate, Dropout, GlobalAveragePooling2D
from sklearn.model_selection import train_test_split
from keras.layers import AveragePooling2D, Input
from keras.models import Model
from keras.layers import Dense, Flatten,MaxPooling2D
from keras.layers import Dense, Conv2D
from keras.optimizers import Adam
import os
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
import logging
logging.getLogger('tensorflow').disabled = True
import warnings
warnings.filterwarnings("ignore")
sq1x1 = "squeeze1x1"
exp1x1 = "expand1x1"
exp3x3 = "expand3x3"
relu = "relu_"

import numpy as np

def main(xx,yy,tr):
    x_train, x_test, y_train, y_test = train_test_split(xx, yy, test_size=tr, random_state=0)
    x_train,x_test=np.array(x_train),np.array(x_test)
    y_train,y_test=np.array(y_train),np.array(y_test)
    parameters = []
    batch_size = 32
    epochs = 5
    data_augmentation = True
    num_classes =3
    loss = 'mean_squared_error'
    learning = 0.0001
    eps = 1e-08
    beta = 0.966
    betaa = 0.999
    optimizer = 'adam'
    subtract_pixel_mean = True
    n = 3
    version = 1
    if version == 1:
        depth = n * 6 + 2
    elif version == 2:
        depth = n * 9 + 2
    predict = []
    for i in range(len(y_train)): predict.append(y_train[i])
    model_type = 'ResNet % dv % d' % (depth, version)
    input_shape = x_train.shape[1:]
    y_train = y_train.astype('int')
    x_train = x_train.astype('float32') / 255
    x_test = x_test.astype('float32') / 255
    y_test = y_test.astype('int')
    # y_train = keras.utils.to_categorical(y_train, num_classes)
    # y_test = keras.utils.to_categorical(y_test, num_classes)
    def lr_schedule(epoch):
        lr = 0.25
        if epoch > 180:
            lr *= 0.5e-3
        elif epoch > 160:
            lr *= 1e-3
        elif epoch > 120:
            lr *= 1e-2
        elif epoch > 80:
            lr *= 1e-1
        return lr
####################### Google Net ############################

    def Inception_block(input_layer, f1, f2_conv1, f2_conv3, f3_conv1, f3_conv5, f4):
        path1 = Conv2D(filters=f1, kernel_size=(1, 1), padding='same', activation='relu')(input_layer)
        path2 = Conv2D(filters=f2_conv1, kernel_size=(1, 1), padding='same', activation='relu')(input_layer)
        path2 = Conv2D(filters=f2_conv3, kernel_size=(3, 3), padding='same', activation='relu')(path2)
        path3 = Conv2D(filters=f3_conv1, kernel_size=(1, 1), padding='same', activation='relu')(input_layer)
        path3 = Conv2D(filters=f3_conv5, kernel_size=(5, 5), padding='same', activation='relu')(path3)
        path4 = MaxPooling2D((3, 3), strides=(1, 1), padding='same')(input_layer)
        path4 = Conv2D(filters=f4, kernel_size=(1, 1), padding='same', activation='relu')(path4)
        output_layer = concatenate([path1, path2, path3, path4], axis=-1)
        return output_layer

    input_layer = Input(shape=(224, 224, 3))
    X = Conv2D(filters=64, kernel_size=(7, 7), strides=2, padding='valid', activation='relu')(input_layer)
    X = MaxPooling2D(pool_size=(3, 3), strides=2)(X)
    X = Conv2D(filters=64, kernel_size=(1, 1), strides=1, padding='same', activation='relu')(X)
    X = Conv2D(filters=192, kernel_size=(3, 3), padding='same', activation='relu')(X)
    X = MaxPooling2D(pool_size=(3, 3), strides=2)(X)
    X = Inception_block(X, f1=64, f2_conv1=96, f2_conv3=128, f3_conv1=16, f3_conv5=32, f4=32)
    X = Inception_block(X, f1=128, f2_conv1=128, f2_conv3=192, f3_conv1=32, f3_conv5=96, f4=64)
    X = MaxPooling2D(pool_size=(3, 3), strides=2)(X)
    X = Inception_block(X, f1=192, f2_conv1=96, f2_conv3=208, f3_conv1=16, f3_conv5=48, f4=64)
    X1 = AveragePooling2D(pool_size=(5, 5), strides=3)(X)
    X1 = Conv2D(filters=128, kernel_size=(1, 1), padding='same', activation='relu')(X1)
    X1 = Flatten()(X1)
    X1 = Dense(1024, activation='relu')(X1)
    X1 = Dropout(0.7)(X1)
    X1 = Dense(num_classes, activation='softmax')(X1)
    X = Inception_block(X, f1=160, f2_conv1=112, f2_conv3=224, f3_conv1=24, f3_conv5=64, f4=64)
    X = Inception_block(X, f1=128, f2_conv1=128, f2_conv3=256, f3_conv1=24, f3_conv5=64, f4=64)
    X = Inception_block(X, f1=112, f2_conv1=144, f2_conv3=288, f3_conv1=32, f3_conv5=64, f4=64)
    X2 = AveragePooling2D(pool_size=(5, 5), strides=3)(X)
    X2 = Conv2D(filters=128, kernel_size=(1, 1), padding='same', activation='relu')(X2)
    X2 = Flatten()(X2)
    X2 = Dense(1024, activation='relu')(X2)
    X2 = Dropout(0.7)(X2)
    X2 = Dense(num_classes, activation='softmax')(X2)
    X = Inception_block(X, f1=256, f2_conv1=160, f2_conv3=320, f3_conv1=32,
                        f3_conv5=128, f4=128)
    X = MaxPooling2D(pool_size=(3, 3), strides=2)(X)
    X = Inception_block(X, f1=256, f2_conv1=160, f2_conv3=320, f3_conv1=32, f3_conv5=128, f4=128)
    X = Inception_block(X, f1=384, f2_conv1=192, f2_conv3=384, f3_conv1=48, f3_conv5=128, f4=128)
    X = GlobalAveragePooling2D(name='GAPL')(X)
    X = Dropout(0.4)(X)
    X = Dense(1, activation='softmax')(X)
    model = Model(input_layer, [X, X1, X2], name='GoogLeNet')
    optimizer = Adam(lr=learning, beta_1=beta, beta_2=betaa, epsilon=eps)
    model.compile(optimizer=optimizer, loss=loss, metrics=['mse'])
    y_train_n121 = np.resize(y_train, (100, 2))
    x_train_n1 = (np.resize(x_train, (100, 224, 224, 3)))
    asd = np.shape(y_train_n121)
    y_train_n121 = (np.resize(y_train, (100, asd[1])))
    qq = [0, 0, 0]

    qq[0] = y_train_n121
    qq[1] = y_train_n121
    qq[2] = y_train_n121
    y_train = np.resize(y_train,(100,y_train.shape[1]))
    model.fit(x_train_n1, y_train, batch_size=batch_size,verbose=0, epochs=epochs)
    goo = model.get_weights()
    x_train_n1 = (np.resize(x_test, (100, 224, 224, 3)))
    p = model.predict(x_train_n1)
    return p,goo

