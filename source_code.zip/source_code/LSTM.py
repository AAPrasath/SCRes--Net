import math
import cv2
from keras.models import Sequential

model = Sequential()
# Import the libraries
import math
import numpy as np
from sklearn.preprocessing import MinMaxScaler
from keras.models import Sequential
from keras.layers import Dense, LSTM
from sklearn.model_selection import train_test_split


def main(Data, Label, tr,ACC, SENS, SPEC):
    Label = np.array(Label)
    x = Data
    X_train, X_test, y_train, y_test = train_test_split(Data, Label, train_size=tr,
                                                        random_state=42)  # 70% for train and 30% for test

    xt = len(X_train)
    yt = len(X_test)
    X_train = np.resize(X_train, (xt, 32, 3))
    X_test = np.resize(X_test, (yt, 32, 3))

    y_train = y_train.astype('int')
    # Normalize data.
    X_train = X_train.astype('float32') / 255
    X_test = X_test.astype('float32') / 255
    y_test = y_test.astype('int')

    # create and fit the LSTM network
    model = Sequential()
    model.add(LSTM(4,input_shape=X_train[0].shape))
    model.add(Dense(1))
    model.compile(loss='mean_squared_error', optimizer='sgd')
    model.fit(X_train, y_train, epochs=20, batch_size=32, verbose=0)

    pred = model.predict(X_test)




















