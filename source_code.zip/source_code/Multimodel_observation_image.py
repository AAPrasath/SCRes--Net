import numpy as np
import  cv2
from Main.conv_2d import convolve2D

def Edge_Extraction_Network(data):

    # converting to gray scale
    gray = cv2.cvtColor(data, cv2.COLOR_BGR2GRAY)

    # gaussian filter
    Gaussian = cv2.GaussianBlur(gray, (3, 3), 0)

    #sobel
    sobelx = cv2.Sobel(Gaussian, cv2.CV_64F, 1, 0, ksize=5)  # x
    sobely = cv2.Sobel(Gaussian, cv2.CV_64F, 0, 1, ksize=5)  # y

    #convoltion kernal  Edge Detection Kernel
    kernel = np.array([[-1, -1, -1], [-1, 8, -1], [-1, -1, -1]])

    # Convolve and Save Output
    output = convolve2D(sobelx, kernel, padding=2)
    return output

