import cv2
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
import numpy as np
from Proposed_SCRes_Net.DRN import DRN_
from Proposed_SCRes_Net.SCNN import SCNN

def SCResNet_model(Sc, weight, O1, target, tr):
    Sc = np.array(Sc)
    alp = 10
    y = Sc * weight
    y1 = O1

    # apply fractional
    a = alp * y
    b = (1 / 2) * alp * y1
    a = np.array(a)
    for i in range(len(b)):
            a[i] = a[i] + b[i]
    O2 = a.copy()
    x = Sc * O2

    x = np.array(x)
    x = np.resize(x, (x.shape[0], x.shape[1]))
    # split data
    X_train, X_test, y_train, y_test = train_test_split(x, target, random_state=1, train_size=tr, shuffle=True)

    classifier = LinearRegression()
    classifier.fit(X_train, y_train)
    prediction = classifier.predict(x)
    out = np.array(prediction)
    return out


def main(Sc, F, y, tr, ACC, SENS, SPEC):

    # Hybrid Sc-Res-Net....
    # call DRN model...
    O1, weight = DRN_(F, y, tr)
    # call SCResNet_model...
    O2 = SCResNet_model(Sc,weight, O1, y, tr)
    # call SCNN model...
    O3 = SCNN(O2, Sc, y, tr, ACC, SENS, SPEC)

    return O3

