from Proposed_SCRes_Net import google_net
from Proposed_SCRes_Net import LSTM
from Proposed_SCRes_Net import GRLSTM

def run(feat1,lab1, lab2, tr, ACC, SEN, SPE):

    # Google Network...
    lab1 = lab1[:,1:2]; lab2 = lab2[:, 1]
    pred, w = google_net.main(feat1, lab1, tr)

    # GRLSTM......
    P = GRLSTM.main(feat1, lab1, tr, pred, w)

    # LSTM Network.....
    LSTM.main(P, lab2, tr, ACC, SEN, SPE)