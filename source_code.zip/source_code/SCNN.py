from tensorflow.keras.layers import Conv2D
from tensorflow.keras.layers import Dense
from tensorflow.keras.layers import Dropout
from tensorflow.keras.layers import GlobalAveragePooling2D
from tensorflow.keras.layers import MaxPooling2D
from keras.layers import Dense
from keras.layers import Input
from keras.models import Model
from sklearn.model_selection import train_test_split
import numpy as np
from  keras.utils import to_categorical
import keras

def SCNN(x,sc, y, tr, ACC, SENS, SPEC):
    def build_siamese_model(inputs, embeddingDim=48):
        # define the first set of CONV => RELU => POOL => DROPOUT layers
        x = Conv2D(64, (2, 2), padding="same", activation="relu")(inputs)
        x = MaxPooling2D(pool_size=(2, 2))(x)
        x = Dropout(0.3)(x)
        # second set of CONV => RELU => POOL => DROPOUT layers
        x = Conv2D(64, (2, 2), padding="same", activation="relu")(x)
        x = MaxPooling2D(pool_size=2)(x)
        x = Dropout(0.3)(x)
        # prepare the final outputs
        pooledOutput = GlobalAveragePooling2D()(x)
        outputs = Dense(embeddingDim)(pooledOutput)

        return outputs

    for i in range(len(sc)):
        sc[i] = sc[i] + x[i]
    x = np.array(sc)
    x = x/255
    # split data
    X_train, X_test, y_train, y_test = train_test_split(x, y, random_state=1, train_size=tr, shuffle=True)
    y_train = to_categorical(y_train); y_t = np.array(y)

    EPOCH = 1
    BATCH_SIZE = 32
    VERB = 0
    input_shape = (32, 32, 3)
    num_class = len(np.unique(y))
    left_input = keras.Input(input_shape)
    right_input = keras.Input(input_shape)

    encoded_l = build_siamese_model(left_input)
    encoded_r = build_siamese_model(right_input)
    subtracted = keras.layers.Subtract()([encoded_l, encoded_r])
    out = Dense(num_class, activation='sigmoid')(subtracted)
    model = Model(inputs=[left_input, right_input], outputs=out)

    model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])

    model.fit([X_train,X_train],[ y_train,y_train], epochs=EPOCH, batch_size=BATCH_SIZE, verbose=VERB)

    predict_ = model.predict([x,x])
    predict = np.argmax(predict_, axis=1)

    target = y_test
    target = np.array(target).flatten()
    tp, tn, fn, fp = 0, 0, 0, 0
    uni = np.unique(target)
    for j in range(len(uni)):
        c = uni[j]
        for i in range(len(target)):
            if target[i] == c and predict[i] == c:
                tp += 1
            if target[i] != c and predict[i] != c:
                tn += 1
            if target[i] == c and predict[i].any() != c:
                fn += 1
            if target[i] != c and predict[i] == c:
                fp += 1

    Accuracy = (tp + tn) / (tp + tn + fp + fn)
    Sensitivity = tp / (tp + fn)
    Specificity = tn / (tn + fp)

    ACC.append(Accuracy)
    SENS.append(Sensitivity)
    SPEC.append(Specificity)

    return predict

