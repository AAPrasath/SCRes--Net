import glob, os, re

# reading path of the images from the folder
def read_image_path(path, type='jpg'):
    f = glob.glob(str(path) + '*.'+type)
    f.sort(key=lambda x: [int(c) if c.isdigit() else c for c in re.split(r'(\d+)', x)])
    return f

# create folder
def create_folder(path):
    if not os.path.exists(path):
        os.makedirs(path)

