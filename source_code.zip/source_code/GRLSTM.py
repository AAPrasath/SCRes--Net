import tensorflow as tf
import numpy as np
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split

def main(data,labels,tr,pred,w):
    data =np.array(data)
    bw =data
    opt = tf.keras.optimizers.legacy.RMSprop()
    m = tf.keras.models.Sequential([tf.keras.layers.Dense(10)])
    m.compile(opt, loss='mse')
    W1=np.mean(w[0][0][0])

    YY = bw *W1
    ############Apply fractional concept
    YY1 = np.resize(pred[0],[bw.shape[0],1])
    h=0.1
    l3 = (h*YY)+(0.5*h*YY1)
    ###Apply regression
    X_train, X_test, y_train, y_test = train_test_split(l3, labels, train_size=tr, random_state=1)
    reg=LinearRegression().fit(X_train, y_train)
    Prediction=reg.predict(X_test)
    predict = np.array(Prediction).flatten()
    predict = np.resize(predict,[bw.shape[0],1])
    ll=np.column_stack((data,predict))
    return ll


