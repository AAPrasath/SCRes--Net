import tensorflow as tf
from keras.utils import to_categorical
from sklearn.model_selection import train_test_split
import numpy as np


def DRN_(x, y, tr):
    uni = np.unique(y)
    num_class = len(uni)

    x = np.array(x).astype('float32')
    x = x/255
    X_train, X_test, y_train, y_test = train_test_split(x , y, random_state=1, train_size=tr, shuffle=True)


    y_train = to_categorical(y_train)
    y_test = to_categorical(y_test)

    def identity_block(x, filter):
        # copy tensor to variable called x_skip
        x_skip = x
        # Layer 1
        x = tf.keras.layers.Conv2D(filter, (3, 3), padding='same')(x)
        x = tf.keras.layers.BatchNormalization(axis=3)(x)
        x = tf.keras.layers.Activation('relu')(x)
        # Layer 2
        x = tf.keras.layers.Conv2D(filter, (3, 3), padding='same')(x)
        x = tf.keras.layers.BatchNormalization(axis=3)(x)
        # Add Residue
        x = tf.keras.layers.Add()([x, x_skip])
        x = tf.keras.layers.Activation('relu')(x)
        return x

    def residual_block(x, filter):
        # copy tensor to variable called x_skip
        x_skip = x
        # Layer 1
        x = tf.keras.layers.Conv2D(filter, (3, 3), padding='same', strides=(2, 2))(x)
        x = tf.keras.layers.BatchNormalization(axis=3)(x)
        x = tf.keras.layers.Activation('relu')(x)
        # Layer 2
        x = tf.keras.layers.Conv2D(filter, (3, 3), padding='same')(x)
        x = tf.keras.layers.BatchNormalization(axis=3)(x)
        # Processing Residue with conv(1,1)
        x_skip = tf.keras.layers.Conv2D(filter, (1, 1), strides=(2, 2))(x_skip)
        # Add Residue
        x = tf.keras.layers.Add()([x, x_skip])
        x = tf.keras.layers.Activation('relu')(x)
        return x

    def ResNet34(shape=(32, 32, 3), classes=num_class):
        # Step 1 (Setup Input Layer)
        x_input = tf.keras.layers.Input(shape)
        x = tf.keras.layers.ZeroPadding2D((3, 3))(x_input)
        # Step 2 (Initial Conv layer along with maxPool)
        x = tf.keras.layers.Conv2D(64, kernel_size=7, strides=2, padding='same')(x)
        x = tf.keras.layers.BatchNormalization()(x)
        x = tf.keras.layers.Activation('relu')(x)
        x = tf.keras.layers.MaxPool2D(pool_size=3, strides=2, padding='same')(x)
        # Define size of sub-blocks and initial filter size
        block_layers = [3, 4, 6, 3]
        filter_size = 64
        # Step 3 Add the Resnet Blocks
        for i in range(4):
            if i == 0:
                # For sub-block 1 Residual/Convolutional block not needed
                for j in range(block_layers[i]):
                    x = identity_block(x, filter_size)
            else:
                # One Residual/Convolutional Block followed by Identity blocks
                # The filter size will go on increasing by a factor of 2
                filter_size = filter_size * 2
                x = residual_block(x, filter_size)
                for j in range(block_layers[i] - 1):
                    x = identity_block(x, filter_size)
        # Step 4 End Dense Network
        x = tf.keras.layers.AveragePooling2D((2, 2), padding='same')(x)
        x = tf.keras.layers.Flatten()(x)
        x = tf.keras.layers.Dense(512, activation='relu')(x)
        x = tf.keras.layers.Dense(classes, activation='softmax')(x)
        model = tf.keras.models.Model(inputs=x_input, outputs=x, name="ResNet34")
        weight = model.get_weights()
        n_weight = np.mean([np.mean(i) for i in weight])
        return model, n_weight

    model, weight = ResNet34()
    model.compile(loss='categorical_crossentropy', optimizer='rmsprop', metrics=['accuracy'])


    model.fit(X_train, y_train, epochs=1, verbose=0)

    prediction = model.predict(x)
    prediction = np.argmax(prediction, axis=1)

    return prediction, weight

