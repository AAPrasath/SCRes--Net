import matplotlib.pyplot as plt
from Main import Multimodel_observation_image
from Main import U_BiSeNet_model
import cv2
import csv
import os
import numpy as np
import function
import SC_ResNet
import google_LSTM

def call_run(tr, data):


    # create output folder
    edge_path = './Edge_extraction'
    function.create_folder(edge_path)
    seg_path = 'Semantic_Segmentation'
    function.create_folder(seg_path)
    ACC, SEN, SPE = [], [], []


    for i in range(5):
        vid_edg = edge_path + '/' + str(i + 1)
        vid_seg = seg_path + '/' + str(i + 1)

        # create folder
        function.create_folder(vid_edg)
        function.create_folder(vid_seg)

        # call function
        data, edge_path , seg_path= i+1, vid_edg, vid_seg

        data_fold = '..\\Dataset\\' + str(data)

        # get all images name
        data_lst = os.listdir(data_fold)
        # to  get  frames from seperate folder the loop starts here
        for i in range(len(data_lst)):
            print(i)
            # get the video from folder
            full_filename = os.path.join(data_fold, data_lst[i])

            # get the file name
            da = os.path.abspath(full_filename)

            # read frame....
            data = cv2.imread(da)

            # Resize the image
            resized_image = cv2.resize(data, (256, 256),
                                       interpolation=cv2.INTER_AREA)  # Use cv2.INTER_AREA for high-quality resizing

            # Multimodel image observation...
            edge_sav_path = edge_path + '/' + data_lst[i]
            output = Multimodel_observation_image.Edge_Extraction_Network(data)
            plt.imsave(edge_sav_path, output, cmap='gray')

            # Scene Understanding using BiSeNet model.....
            seg_sav_path = seg_path + '/' + data_lst[i]
            seg5 = U_BiSeNet_model.run(resized_image, output)
            plt.imsave(seg_sav_path, seg5, cmap='gray')

    # read path of images
    in_path = '../Dataset/' + data + '/'
    frame_path = function.read_image_path(in_path, 'png')
    path = './Semantic_Segmentation/' + data + '/'
    scene_path = function.read_image_path(path, 'png')

    # read each image from the folder:
    Sc, F = [], []
    size = (32, 32)
    for i in range(len(frame_path)):
        # read data
        frame = cv2.imread(frame_path[i])
        scene = cv2.imread(scene_path[i])

        # resize
        frame = cv2.resize(frame, size)
        scene = cv2.resize(scene, size)
        F.append(frame)
        Sc.append(scene)
    dt = Sc.copy()
    fin_lab1 = []
    # Open file
    with open('../Dataset/steering' + data + '.csv') as file_obj:
        # Create reader object by passing the file
        # object to reader method
        reader_obj = csv.reader(file_obj)

        # Iterate over each row in the csv
        # file using reader object
        for row in reader_obj:
            row[0] = row[0].replace(',', '\n')
            x = row[0].splitlines()
            for i in range(len(x)):
                x[i] = float(x[i])
            fin_lab1.append(x)

    lab = np.load('../Dataset/video' + data + '.npy')
    lab = np.array(lab)
    lab_ = np.array(fin_lab1)

    fin_lab2 = []
    # Open file
    with open('../Dataset/speed' + data + '.csv') as file_obj:
        # Create reader object by passing the file
        # object to reader method
        reader_obj = csv.reader(file_obj)

        # Iterate over each row in the csv
        # file using reader object
        for row in reader_obj:
            row[0] = row[0].replace(',', '\n')
            x = row[0].splitlines()
            for i in range(len(x)):
                x[i] = float(x[i])
            fin_lab2.append(x)
    fin_lab2 = np.array(fin_lab2)

    # Running Hybrid Sc-Res-Net...
    print('\nRunning Proposed_SCRes_Net Hybrid Sc-Res-Net....')
    fea = SC_ResNet.main(dt, F, lab, tr, ACC, SEN, SPE)

    # Running Google - LSTM....
    print('\nRunning Google - LSTM....')
    google_LSTM.run(fea, lab_, fin_lab2, tr, ACC, SEN, SPE)

    return ACC, SEN, SPE
