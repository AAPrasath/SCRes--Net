import numpy as np
import cv2
from  Main.U_BiSeNet import regression
from Main.U_BiSeNet import Adam_weight, BiSeNet
from Main.U_BiSeNet.keras_segmentation.models.unet import unet_mini

def run(resized_image, output):
    ########Hybrid network
    ######BiSeNet
    seg = BiSeNet.main(resized_image)

    #######
    W1 = Adam_weight.main()
    #####rEsize
    new_size = (256, 256)  # Replace width and height with the desired dimensions

    # Resize the image
    seg = cv2.resize(seg, new_size,
                     interpolation=cv2.INTER_AREA)  # Use cv2.INTER_AREA for high-quality resizing
    output = cv2.resize(output, new_size,
                        interpolation=cv2.INTER_AREA)  # Use cv2.INTER_AREA for high-quality resizing
    ####Apply fractional
    out = abs(W1) * seg + (1 / 2 * abs(W1) * output)
    #####Apply regression
    R = regression.main(out)
    #####unet
    new_model = unet_mini(n_classes=2)
    new_model.load_weights('./unet.00001')

    out = new_model.predict_segmentation(inp=resized_image, out_fname='out.png')

    out = out.astype('uint8')
    kernel = np.ones((9, 9), np.uint8)
    #out = cv2.erode(out, kernel)
    segmented = cv2.dilate(out, kernel, iterations=1)
    im_invert = np.invert(out)
    return im_invert







































































































































